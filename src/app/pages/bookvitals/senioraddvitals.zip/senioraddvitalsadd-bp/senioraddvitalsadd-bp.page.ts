import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-senioraddvitalsadd-bp',
  templateUrl: './senioraddvitalsadd-bp.page.html',
  styleUrls: ['./senioraddvitalsadd-bp.page.scss'],
})
export class SenioraddvitalsaddBPPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
