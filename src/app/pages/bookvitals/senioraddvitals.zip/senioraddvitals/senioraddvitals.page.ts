import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-senioraddvitals',
  templateUrl: './senioraddvitals.page.html',
  styleUrls: ['./senioraddvitals.page.scss'],
})
export class SenioraddvitalsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
